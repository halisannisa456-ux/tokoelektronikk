<?php
include '../config/database.php';

// Proses TAMBAH
if (isset($_POST['tambah'])) {
    $id_karyawan = clean_input($_POST['id_karyawan']);
    $nama = clean_input($_POST['nama']);
    $posisi = clean_input($_POST['posisi']);

    $query = "INSERT INTO karyawan (id_karyawan, nama, posisi) 
              VALUES ('$id_karyawan', '$nama', '$posisi')";
    
    if (mysqli_query($conn, $query)) {
        $success = "Data karyawan berhasil ditambahkan!";
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}

// Proses EDIT  
if (isset($_POST['edit'])) {
    $id_karyawan = clean_input($_POST['id_karyawan']);
    $nama = clean_input($_POST['nama']);
    $posisi = clean_input($_POST['posisi']);
    $id_lama = clean_input($_POST['id_lama']);
    
    $query = "UPDATE karyawan SET 
              id_karyawan='$id_karyawan', 
              nama='$nama', 
              posisi='$posisi' 
              WHERE id_karyawan='$id_lama'";
    
    if (mysqli_query($conn, $query)) {
        $success = "Data karyawan berhasil diupdate!";
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}

// Proses HAPUS
if (isset($_GET['hapus'])) {
    $id = clean_input($_GET['hapus']);
    $query = "DELETE FROM karyawan WHERE id_karyawan='$id'";
    
    if (mysqli_query($conn, $query)) {
        $success = "Data karyawan berhasil dihapus!";
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}

// Ambil data untuk edit
$edit_data = null;
if (isset($_GET['edit'])) {
    $id = clean_input($_GET['edit']);
    $query = "SELECT * FROM karyawan WHERE id_karyawan='$id'";
    $result = mysqli_query($conn, $query);
    $edit_data = mysqli_fetch_assoc($result);
}

// Ambil semua data
$query = "SELECT * FROM karyawan ORDER BY id_karyawan";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Master Karyawan - Toko Elektronik</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <!-- SIDEBAR -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>💗 Toko Elektronik</h2>
            </div>

            <div class="nav-section">
                <p class="nav-title">Master Data</p>
                <a class="nav-item" href="pelanggan.php">Pelanggan</a>
                <a class="nav-item" href="produk.php">Produk</a>
                <a class="nav-item" href="kategori.php">Kategori</a>
                <a class="nav-item" href="supplier.php">Supplier</a>
                <a class="nav-item active" href="karyawan.php">Karyawan</a>
                <a class="nav-item" href="metode_pembayaran.php">Metode Pembayaran</a>
                <a class="nav-item" href="ekspedisi.php">Ekspedisi</a>
                <a class="nav-item" href="gudang.php">Gudang</a>
            </div>

            <div class="nav-section">
                <p class="nav-title">Transaksi</p>
                <a class="nav-item" href="../transaksi/transaksi_penjualan.php">Transaksi Penjualan</a>
                <a class="nav-item" href="../transaksi/transaksi_retur_penjualan.php">Retur Penjualan</a>
                <a class="nav-item" href="../transaksi/transaksi_retur_pembelian.php">Retur Pembelian</a>
                <a class="nav-item" href="../transaksi/transaksi_pengiriman.php">Pengiriman</a>
                <a class="nav-item" href="../transaksi/transaksi_pembayaran.php">Pembayaran</a>
            </div>

            <div class="nav-section">
                <p class="nav-title">Laporan</p>
                <a class="nav-item" href="../laporan/laporan_penjualan.php">Laporan Penjualan</a>
                <a class="nav-item" href="../laporan/laporan_pengiriman.php">Laporan Pengiriman</a>
            </div>

            <div class="nav-section">
                <p class="nav-title">Dashboard</p>
                <a class="nav-item" href="../index.php">🏠 Dashboard</a>
            </div>
        </div>

        <!-- CONTENT -->
        <div class="content">
            <div class="header">
                <h1>Master Karyawan 👔</h1>
                <div class="user-avatar">A</div>
            </div>

            <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <button id="btnToggleForm" class="btn-primary mb-20">
                <?php echo $edit_data ? '✖ Batal Edit' : '+ Tambah Karyawan'; ?>
            </button>

            <!-- FORM -->
            <section class="form-container mb-20" id="formSection" style="<?php echo $edit_data ? '' : 'display: none;'; ?>">
                <h2 style="color: #d86aa3; margin-bottom: 20px;">
                    <?php echo $edit_data ? 'Edit Karyawan' : 'Tambah Karyawan'; ?>
                </h2>

                <form method="POST" action="">
                    <?php if ($edit_data): ?>
                    <input type="hidden" name="id_lama" value="<?php echo $edit_data['id_karyawan']; ?>">
                    <?php endif; ?>
                    
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px;">
                        <div class="form-group">
                            <label>ID Karyawan</label>
                            <input type="text" name="id_karyawan" class="form-control" 
                                   value="<?php echo $edit_data ? $edit_data['id_karyawan'] : ''; ?>" 
                                   required>
                        </div>

                        <div class="form-group">
                            <label>Nama</label>
                            <input type="text" name="nama" class="form-control" 
                                   value="<?php echo $edit_data ? $edit_data['nama'] : ''; ?>" 
                                   required>
                        </div>

                        <div class="form-group">
                            <label>Posisi</label>
                            <input type="text" name="posisi" class="form-control" 
                                   value="<?php echo $edit_data ? $edit_data['posisi'] : ''; ?>">
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" name="<?php echo $edit_data ? 'edit' : 'tambah'; ?>" class="btn-primary">
                            <?php echo $edit_data ? 'Update' : 'Simpan'; ?>
                        </button>
                        <?php if ($edit_data): ?>
                        <a href="karyawan.php" class="btn-cancel">Batal</a>
                        <?php endif; ?>
                    </div>
                </form>
            </section>

            <!-- TABLE -->
            <div class="table-container">
                <h3 style="color: #d86aa3; margin-bottom: 20px;">Daftar Karyawan</h3>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID karyawan</th>
                            <th>Nama</th>
                            <th>Posisi</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if (mysqli_num_rows($result) > 0):
                            while ($row = mysqli_fetch_assoc($result)): 
                        ?>
                        <tr>
                            <td><?php echo $row['id_karyawan']; ?></td>
                            <td><?php echo $row['nama']; ?></td>
                            <td><?php echo $row['posisi']; ?></td>
                            <td>
                                <div class="action-buttons">
                                    <a href="?edit=<?php echo $row['id_karyawan']; ?>" class="btn-edit">Edit</a>
                                    <a href="?hapus=<?php echo $row['id_karyawan']; ?>" 
                                       class="btn-delete" 
                                       onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                                </div>
                            </td>
                        </tr>
                        <?php 
                            endwhile;
                        else:
                        ?>
                        <tr>
                            <td colspan="7" class="text-center">Belum ada data karyawan</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('btnToggleForm').addEventListener('click', function() {
            const form = document.getElementById('formSection');
            const btn = this;
            
            if (form.style.display === 'none') {
                form.style.display = 'block';
                btn.textContent = '✖ Tutup Form';
            } else {
                form.style.display = 'none';
                btn.textContent = '+ Tambah Karyawan';
            }
        });
    </script>
</body>
</html>
