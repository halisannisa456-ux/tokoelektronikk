<?php
include '../config/database.php';

// Proses TAMBAH
if (isset($_POST['tambah'])) {
    $id_pengiriman = clean_input($_POST['id_pengiriman']);
    $id_transaksi = clean_input($_POST['id_transaksi']);
    $id_ekspedisi = clean_input($_POST['id_ekspedisi']);
    $status = clean_input($_POST['status']);
    $tanggal_kirim = clean_input($_POST['tanggal_kirim']);
    $tanggal_terima = clean_input($_POST['tanggal_terima']);
    
    $query = "INSERT INTO transaksi_pengiriman (id_pengiriman, id_transaksi, id_ekspedisi, status, tanggal_kirim, tanggal_terima) 
              VALUES ('$id_pengiriman', '$id_transaksi', '$id_ekspedisi', '$status', '$tanggal_kirim', '$tanggal_terima')";
    
    if (mysqli_query($conn, $query)) {
        $success = "Data pengiriman berhasil ditambahkan!";
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}

// Proses EDIT
if (isset($_POST['edit'])) {
    $id_pengiriman = clean_input($_POST['id_pengiriman']);
    $id_transaksi = clean_input($_POST['id_transaksi']);
    $id_ekspedisi = clean_input($_POST['id_ekspedisi']);
    $status = clean_input($_POST['status']);
    $tanggal_kirim = clean_input($_POST['tanggal_kirim']);
    $tanggal_terima = clean_input($_POST['tanggal_terima']);
    $id_lama = clean_input($_POST['id_lama']);
    
    $query = "UPDATE transaksi_pengiriman SET 
              id_pengiriman='$id_pengiriman',
              id_transaksi='$id_transaksi', 
              id_ekspedisi='$id_ekspedisi', 
              status='$status', 
              tanggal_kirim='$tanggal_kirim', 
              tanggal_terima='$tanggal_terima' 
              WHERE id_pengiriman='$id_lama'";
    
    if (mysqli_query($conn, $query)) {
        $success = "Data pengiriman berhasil diupdate!";
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}

// Proses HAPUS
if (isset($_GET['hapus'])) {
    $id = clean_input($_GET['hapus']);
    $query = "DELETE FROM transaksi_pengiriman WHERE id_pengiriman='$id'";
    
    if (mysqli_query($conn, $query)) {
        $success = "Data pengiriman berhasil dihapus!";
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}

// Ambil data untuk edit
$edit_data = null;
if (isset($_GET['edit'])) {
    $id = clean_input($_GET['edit']);
    $query = "SELECT * FROM transaksi_pengiriman WHERE id_pengiriman='$id'";
    $result = mysqli_query($conn, $query);
    $edit_data = mysqli_fetch_assoc($result);
}

// Ambil data transaksi untuk dropdown
$query_transaksi = "SELECT * FROM transaksi_penjualan ORDER BY id_transaksi DESC";
$result_transaksi = mysqli_query($conn, $query_transaksi);

// Ambil data ekspedisi untuk dropdown
$query_ekspedisi = "SELECT * FROM ekspedisi ORDER BY nama_ekspedisi";
$result_ekspedisi = mysqli_query($conn, $query_ekspedisi);

// Ambil semua data pengiriman dengan JOIN
$query = "SELECT p.*, e.nama_ekspedisi 
          FROM transaksi_pengiriman p
          LEFT JOIN ekspedisi e ON p.id_ekspedisi = e.id_ekspedisi
          ORDER BY p.tanggal_kirim DESC";
$result = mysqli_query($conn, $query);

// Generate ID pengiriman otomatis
function generate_id_pengiriman() {
    global $conn;
    $query = "SELECT id_pengiriman FROM transaksi_pengiriman ORDER BY id_pengiriman DESC LIMIT 1";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $num = intval(substr($row['id_pengiriman'], 3)) + 1;
        return 'KRM' . str_pad($num, 3, '0', STR_PAD_LEFT);
    }
    return 'KRM001';
}
$new_id = generate_id_pengiriman();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaksi Pengiriman - Toko Elektronik</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <!-- SIDEBAR -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>💗 Toko Elektronik</h2>
            </div>

            <div class="nav-section">
                <p class="nav-title">Master Data</p>
                <a class="nav-item" href="../masterdata/pelanggan.php">Pelanggan</a>
                <a class="nav-item" href="../masterdata/produk.php">Produk</a>
                <a class="nav-item" href="../masterdata/kategori.php">Kategori</a>
                <a class="nav-item" href="../masterdata/supplier.php">Supplier</a>
                <a class="nav-item" href="../masterdata/karyawan.php">Karyawan</a>
                <a class="nav-item" href="../masterdata/metode_pembayaran.php">Metode Pembayaran</a>
                <a class="nav-item" href="../masterdata/ekspedisi.php">Ekspedisi</a>
                <a class="nav-item" href="../masterdata/gudang.php">Gudang</a>
            </div>

            <div class="nav-section">
                <p class="nav-title">Transaksi</p>
                <a class="nav-item" href="transaksi_penjualan.php">Transaksi Penjualan</a>
                <a class="nav-item" href="transaksi_retur_penjualan.php">Retur Penjualan</a>
                <a class="nav-item" href="transaksi_retur_pembelian.php">Retur Pembelian</a>
                <a class="nav-item active" href="transaksi_pengiriman.php">Pengiriman</a>
                <a class="nav-item" href="transaksi_pembayaran.php">Pembayaran</a>
            </div>

            <div class="nav-section">
                <p class="nav-title">Laporan</p>
                <a class="nav-item" href="../laporan/laporan_penjualan.php">Laporan Penjualan</a>
                <a class="nav-item" href="../laporan/laporan_pengiriman.php">Laporan Pengiriman</a>
            </div>

            <div class="nav-section">
                <p class="nav-title">Dashboard</p>
                <a class="nav-item" href="../index.php">🏠 Dashboard</a>
            </div>
        </div>

        <!-- CONTENT -->
        <div class="content">
            <div class="header">
                <h1>Transaksi Pengiriman 📦</h1>
                <div class="user-avatar">A</div>
            </div>

            <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <button id="btnToggleForm" class="btn-primary mb-20">
                <?php echo $edit_data ? '✖ Batal Edit' : '+ Tambah Pengiriman'; ?>
            </button>

            <!-- FORM -->
            <section class="form-container mb-20" id="formSection" style="<?php echo $edit_data ? '' : 'display: none;'; ?>">
                <h2 style="color: #d86aa3; margin-bottom: 20px;">
                    <?php echo $edit_data ? 'Edit Pengiriman' : 'Tambah Pengiriman'; ?>
                </h2>

                <form method="POST" action="">
                    <?php if ($edit_data): ?>
                    <input type="hidden" name="id_lama" value="<?php echo $edit_data['id_pengiriman']; ?>">
                    <?php endif; ?>
                    
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px;">
                        <div class="form-group">
                            <label>ID Pengiriman</label>
                            <input type="text" name="id_pengiriman" class="form-control" 
                                   value="<?php echo $edit_data ? $edit_data['id_pengiriman'] : $new_id; ?>" 
                                   required>
                        </div>

                        <div class="form-group">
                            <label>ID Transaksi</label>
                            <select name="id_transaksi" class="form-control" required>
                                <option value="">Pilih Transaksi</option>
                                <?php 
                                mysqli_data_seek($result_transaksi, 0);
                                while($tr = mysqli_fetch_assoc($result_transaksi)): 
                                ?>
                                    <option value="<?php echo $tr['id_transaksi']; ?>"
                                        <?php echo ($edit_data && $edit_data['id_transaksi'] == $tr['id_transaksi']) ? 'selected' : ''; ?>>
                                        <?php echo $tr['id_transaksi']; ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Ekspedisi</label>
                            <select name="id_ekspedisi" class="form-control" required>
                                <option value="">Pilih Ekspedisi</option>
                                <?php 
                                mysqli_data_seek($result_ekspedisi, 0);
                                while($ex = mysqli_fetch_assoc($result_ekspedisi)): 
                                ?>
                                    <option value="<?php echo $ex['id_ekspedisi']; ?>"
                                        <?php echo ($edit_data && $edit_data['id_ekspedisi'] == $ex['id_ekspedisi']) ? 'selected' : ''; ?>>
                                        <?php echo $ex['nama_ekspedisi']; ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Status</label>
                            <select name="status" class="form-control" required>
                                <option value="Dikirim" <?php echo ($edit_data && $edit_data['status'] == 'Dikirim') ? 'selected' : ''; ?>>Dikirim</option>
                                <option value="Diterima" <?php echo ($edit_data && $edit_data['status'] == 'Diterima') ? 'selected' : ''; ?>>Diterima</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Tanggal Kirim</label>
                            <input type="date" name="tanggal_kirim" class="form-control" 
                                   value="<?php echo $edit_data ? $edit_data['tanggal_kirim'] : date('Y-m-d'); ?>" 
                                   required>
                        </div>

                        <div class="form-group">
                            <label>Tanggal Terima</label>
                            <input type="date" name="tanggal_terima" class="form-control" 
                                   value="<?php echo $edit_data ? $edit_data['tanggal_terima'] : ''; ?>">
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" name="<?php echo $edit_data ? 'edit' : 'tambah'; ?>" class="btn-primary">
                            <?php echo $edit_data ? 'Update' : 'Simpan'; ?>
                        </button>
                        <?php if ($edit_data): ?>
                        <a href="transaksi_pengiriman.php" class="btn-cancel">Batal</a>
                        <?php endif; ?>
                    </div>
                </form>
            </section>

            <!-- TABLE -->
            <div class="table-container">
                <h3 style="color: #d86aa3; margin-bottom: 20px;">Daftar Pengiriman</h3>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID Pengiriman</th>
                            <th>ID Transaksi</th>
                            <th>Ekspedisi</th>
                            <th>Status</th>
                            <th>Tanggal Kirim</th>
                            <th>Tanggal Terima</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if (mysqli_num_rows($result) > 0):
                            while ($row = mysqli_fetch_assoc($result)): 
                        ?>
                        <tr>
                            <td><?php echo $row['id_pengiriman']; ?></td>
                            <td><?php echo $row['id_transaksi']; ?></td>
                            <td><?php echo $row['nama_ekspedisi']; ?></td>
                            <td><?php echo $row['status']; ?></td>
                            <td><?php echo $row['tanggal_kirim']; ?></td>
                            <td><?php echo $row['tanggal_terima'] ? $row['tanggal_terima'] : '-'; ?></td>
                            <td>
                                <div class="action-buttons">
                                    <a href="?edit=<?php echo $row['id_pengiriman']; ?>" class="btn-edit">Edit</a>
                                    <a href="?hapus=<?php echo $row['id_pengiriman']; ?>" 
                                       class="btn-delete" 
                                       onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                                </div>
                            </td>
                        </tr>
                        <?php 
                            endwhile;
                        else:
                        ?>
                        <tr>
                            <td colspan="7" class="text-center">Belum ada data pengiriman</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('btnToggleForm').addEventListener('click', function() {
            const form = document.getElementById('formSection');
            const btn = this;
            
            if (form.style.display === 'none') {
                form.style.display = 'block';
                btn.textContent = '✖ Tutup Form';
            } else {
                form.style.display = 'none';
                btn.textContent = '+ Tambah Pengiriman';
            }
        });
    </script>
</body>
</html>