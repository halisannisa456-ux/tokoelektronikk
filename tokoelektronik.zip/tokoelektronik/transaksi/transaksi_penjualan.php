<?php
include '../config/database.php';

// Proses TAMBAH
if (isset($_POST['tambah'])) {
    $id_transaksi = clean_input($_POST['id_transaksi']);
    $id_pelanggan = clean_input($_POST['id_pelanggan']);
    $id_karyawan = clean_input($_POST['id_karyawan']);
    $tanggal_transaksi = clean_input($_POST['tanggal_transaksi']);
    $total_harga = clean_input($_POST['total_harga']);
    $status = clean_input($_POST['status']);
    
    $query = "INSERT INTO transaksi_penjualan (id_transaksi, id_pelanggan, id_karyawan, tanggal_transaksi, total_harga, status) 
              VALUES ('$id_transaksi', '$id_pelanggan', '$id_karyawan', '$tanggal_transaksi', '$total_harga', '$status')";
    
    if (mysqli_query($conn, $query)) {
        $success = "Transaksi penjualan berhasil ditambahkan!";
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}

// Proses EDIT
if (isset($_POST['edit'])) {
    $id_transaksi = clean_input($_POST['id_transaksi']);
    $id_pelanggan = clean_input($_POST['id_pelanggan']);
    $id_karyawan = clean_input($_POST['id_karyawan']);
    $tanggal_transaksi = clean_input($_POST['tanggal_transaksi']);
    $total_harga = clean_input($_POST['total_harga']);
    $status = clean_input($_POST['status']);
    $id_lama = clean_input($_POST['id_lama']);
    
    $query = "UPDATE transaksi_penjualan SET 
              id_transaksi='$id_transaksi',
              id_pelanggan='$id_pelanggan', 
              id_karyawan='$id_karyawan', 
              tanggal_transaksi='$tanggal_transaksi', 
              total_harga='$total_harga', 
              status='$status' 
              WHERE id_transaksi='$id_lama'";
    
    if (mysqli_query($conn, $query)) {
        $success = "Transaksi penjualan berhasil diupdate!";
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}

// Proses HAPUS
if (isset($_GET['hapus'])) {
    $id = clean_input($_GET['hapus']);
    $query = "DELETE FROM transaksi_penjualan WHERE id_transaksi='$id'";
    
    if (mysqli_query($conn, $query)) {
        $success = "Transaksi penjualan berhasil dihapus!";
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}

// Ambil data untuk edit
$edit_data = null;
if (isset($_GET['edit'])) {
    $id = clean_input($_GET['edit']);
    $query = "SELECT * FROM transaksi_penjualan WHERE id_transaksi='$id'";
    $result = mysqli_query($conn, $query);
    $edit_data = mysqli_fetch_assoc($result);
}

// Ambil data pelanggan untuk dropdown
$query_pelanggan = "SELECT * FROM pelanggan ORDER BY id_pelanggan";
$result_pelanggan = mysqli_query($conn, $query_pelanggan);

// Ambil data karyawan untuk dropdown
$query_karyawan = "SELECT * FROM karyawan ORDER BY id_karyawan";
$result_karyawan = mysqli_query($conn, $query_karyawan);

// Ambil semua data transaksi penjualan
$query = "SELECT * FROM transaksi_penjualan ORDER BY tanggal_transaksi DESC";
$result = mysqli_query($conn, $query);

// Generate ID transaksi otomatis
function generate_id_transaksi() {
    global $conn;
    $query = "SELECT id_transaksi FROM transaksi_penjualan ORDER BY id_transaksi DESC LIMIT 1";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $num = intval(substr($row['id_transaksi'], 2)) + 1;
        return 'TR' . str_pad($num, 3, '0', STR_PAD_LEFT);
    }
    return 'TR001';
}
$new_id = generate_id_transaksi();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaksi Penjualan - Toko Elektronik</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <!-- SIDEBAR -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>💗 Toko Elektronik</h2>
            </div>

            <div class="nav-section">
                <p class="nav-title">Master Data</p>
                <a class="nav-item" href="../masterdata/pelanggan.php">Pelanggan</a>
                <a class="nav-item" href="../masterdata/produk.php">Produk</a>
                <a class="nav-item" href="../masterdata/kategori.php">Kategori</a>
                <a class="nav-item" href="../masterdata/supplier.php">Supplier</a>
                <a class="nav-item" href="../masterdata/karyawan.php">Karyawan</a>
                <a class="nav-item" href="../masterdata/metode_pembayaran.php">Metode Pembayaran</a>
                <a class="nav-item" href="../masterdata/ekspedisi.php">Ekspedisi</a>
                <a class="nav-item" href="../masterdata/gudang.php">Gudang</a>
            </div>

            <div class="nav-section">
                <p class="nav-title">Transaksi</p>
                <a class="nav-item active" href="transaksi_penjualan.php">Transaksi Penjualan</a>
                <a class="nav-item" href="transaksi_retur_penjualan.php">Retur Penjualan</a>
                <a class="nav-item" href="transaksi_retur_pembelian.php">Retur Pembelian</a>
                <a class="nav-item" href="transaksi_pengiriman.php">Pengiriman</a>
                <a class="nav-item" href="transaksi_pembayaran.php">Pembayaran</a>
            </div>

            <div class="nav-section">
                <p class="nav-title">Laporan</p>
                <a class="nav-item" href="../laporan/laporan_penjualan.php">Laporan Penjualan</a>
                <a class="nav-item" href="../laporan/laporan_pengiriman.php">Laporan Pengiriman</a>
            </div>

            <div class="nav-section">
                <p class="nav-title">Dashboard</p>
                <a class="nav-item" href="../index.php">🏠 Dashboard</a>
            </div>
        </div>

        <!-- CONTENT -->
        <div class="content">
            <div class="header">
                <h1>Transaksi Penjualan 🛒</h1>
                <div class="user-avatar">A</div>
            </div>

            <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <button id="btnToggleForm" class="btn-primary mb-20">
                <?php echo $edit_data ? '✖ Batal Edit' : '+ Tambah Transaksi'; ?>
            </button>

            <!-- FORM -->
            <section class="form-container mb-20" id="formSection" style="<?php echo $edit_data ? '' : 'display: none;'; ?>">
                <h2 style="color: #d86aa3; margin-bottom: 20px;">
                    <?php echo $edit_data ? 'Edit Transaksi Penjualan' : 'Tambah Transaksi Penjualan'; ?>
                </h2>

                <form method="POST" action="">
                    <?php if ($edit_data): ?>
                    <input type="hidden" name="id_lama" value="<?php echo $edit_data['id_transaksi']; ?>">
                    <?php endif; ?>
                    
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px;">
                        <div class="form-group">
                            <label>ID Transaksi</label>
                            <input type="text" name="id_transaksi" class="form-control" 
                                   value="<?php echo $edit_data ? $edit_data['id_transaksi'] : $new_id; ?>" 
                                   required>
                        </div>

                        <div class="form-group">
                            <label>Pelanggan</label>
                            <select name="id_pelanggan" class="form-control" required>
                                <option value="">Pilih Pelanggan</option>
                                <?php 
                                mysqli_data_seek($result_pelanggan, 0);
                                while($plg = mysqli_fetch_assoc($result_pelanggan)): 
                                ?>
                                    <option value="<?php echo $plg['id_pelanggan']; ?>"
                                        <?php echo ($edit_data && $edit_data['id_pelanggan'] == $plg['id_pelanggan']) ? 'selected' : ''; ?>>
                                        <?php echo $plg['nama']; ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Karyawan</label>
                            <select name="id_karyawan" class="form-control" required>
                                <option value="">Pilih Karyawan</option>
                                <?php 
                                mysqli_data_seek($result_karyawan, 0);
                                while($kar = mysqli_fetch_assoc($result_karyawan)): 
                                ?>
                                    <option value="<?php echo $kar['id_karyawan']; ?>"
                                        <?php echo ($edit_data && $edit_data['id_karyawan'] == $kar['id_karyawan']) ? 'selected' : ''; ?>>
                                        <?php echo $kar['nama']; ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Tanggal Transaksi</label>
                            <input type="date" name="tanggal_transaksi" class="form-control" 
                                   value="<?php echo $edit_data ? $edit_data['tanggal_transaksi'] : date('Y-m-d'); ?>" 
                                   required>
                        </div>

                        <div class="form-group">
                            <label>Total Harga</label>
                            <input type="number" name="total_harga" class="form-control" step="0.01"
                                   value="<?php echo $edit_data ? $edit_data['total_harga'] : '0'; ?>" 
                                   required>
                        </div>

                        <div class="form-group">
                            <label>Status</label>
                            <select name="status" class="form-control" required>
                                <option value="Pending" <?php echo ($edit_data && $edit_data['status'] == 'Pending') ? 'selected' : ''; ?>>Pending</option>
                                <option value="Diproses" <?php echo ($edit_data && $edit_data['status'] == 'Diproses') ? 'selected' : ''; ?>>Diproses</option>
                                <option value="Selesai" <?php echo ($edit_data && $edit_data['status'] == 'Selesai') ? 'selected' : ''; ?>>Selesai</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" name="<?php echo $edit_data ? 'edit' : 'tambah'; ?>" class="btn-primary">
                            <?php echo $edit_data ? 'Update' : 'Simpan'; ?>
                        </button>
                        <?php if ($edit_data): ?>
                        <a href="transaksi_penjualan.php" class="btn-cancel">Batal</a>
                        <?php endif; ?>
                    </div>
                </form>
            </section>

            <!-- TABLE -->
            <div class="table-container">
                <h3 style="color: #d86aa3; margin-bottom: 20px;">Daftar Transaksi Penjualan</h3>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID Transaksi</th>
                            <th>Tanggal</th>
                            <th>Pelanggan</th>
                            <th>Karyawan</th>
                            <th>Total Harga</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if (mysqli_num_rows($result) > 0):
                            while ($row = mysqli_fetch_assoc($result)): 
                        ?>
                        <tr>
                            <td><?php echo $row['id_transaksi']; ?></td>
                            <td><?php echo $row['tanggal_transaksi']; ?></td>
                            <td><?php echo $row['id_pelanggan']; ?></td>
                            <td><?php echo $row['id_karyawan']; ?></td>
                            <td>Rp <?php echo number_format($row['total_harga'], 0, ',', '.'); ?></td>
                            <td><?php echo $row['status']; ?></td>
                            <td>
                                <div class="action-buttons">
                                    <a href="?edit=<?php echo $row['id_transaksi']; ?>" class="btn-edit">Edit</a>
                                    <a href="?hapus=<?php echo $row['id_transaksi']; ?>" 
                                       class="btn-delete" 
                                       onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                                </div>
                            </td>
                        </tr>
                        <?php 
                            endwhile;
                        else:
                        ?>
                        <tr>
                            <td colspan="7" class="text-center">Belum ada transaksi penjualan</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('btnToggleForm').addEventListener('click', function() {
            const form = document.getElementById('formSection');
            const btn = this;
            
            if (form.style.display === 'none') {
                form.style.display = 'block';
                btn.textContent = '✖ Tutup Form';
            } else {
                form.style.display = 'none';
                btn.textContent = '+ Tambah Transaksi';
            }
        });
    </script>
</body>
</html>