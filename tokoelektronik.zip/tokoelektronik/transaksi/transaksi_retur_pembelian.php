<?php
include '../config/database.php';

// Generate ID Retur Pembelian
function generate_id_retur() {
    global $conn;
    $query = "SELECT id_retur_pembelian FROM transaksi_retur_pembelian ORDER BY id_retur_pembelian DESC LIMIT 1";
    $result = mysqli_query($conn, $query);
    
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $last_id = $row['id_retur_pembelian'];
        $num = intval(substr($last_id, 2)) + 1;
        return 'RP' . str_pad($num, 3, '0', STR_PAD_LEFT);
    }
    return 'RP001';
}

// Proses TAMBAH Retur Pembelian
if (isset($_POST['tambah'])) {
    $id_retur = clean_input($_POST['id_retur_pembelian']);
    $id_supplier = clean_input($_POST['id_supplier']);
    $id_produk = clean_input($_POST['id_produk']);
    $qty_retur = clean_input($_POST['qty_retur']);
    $alasan = clean_input($_POST['alasan']);
    $tanggal_retur = clean_input($_POST['tanggal_retur']);
    
    $query = "INSERT INTO transaksi_retur_pembelian (id_retur_pembelian, id_supplier, id_produk, qty_retur, alasan, tanggal_retur) 
              VALUES ('$id_retur', '$id_supplier', '$id_produk', '$qty_retur', '$alasan', '$tanggal_retur')";
    
    if (mysqli_query($conn, $query)) {
        // Kurangi stok produk
        $update_stok = "UPDATE produk SET stok = stok - $qty_retur WHERE id_produk = '$id_produk'";
        mysqli_query($conn, $update_stok);
        
        $success = "Retur pembelian berhasil ditambahkan!";
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}

// Proses EDIT
if (isset($_POST['edit'])) {
    $id_retur = clean_input($_POST['id_retur_pembelian']);
    $id_supplier = clean_input($_POST['id_supplier']);
    $id_produk = clean_input($_POST['id_produk']);
    $qty_retur = clean_input($_POST['qty_retur']);
    $alasan = clean_input($_POST['alasan']);
    $tanggal_retur = clean_input($_POST['tanggal_retur']);
    $id_lama = clean_input($_POST['id_lama']);
    
    $query = "UPDATE transaksi_retur_pembelian SET 
              id_retur_pembelian='$id_retur',
              id_supplier='$id_supplier', 
              id_produk='$id_produk', 
              qty_retur='$qty_retur', 
              alasan='$alasan', 
              tanggal_retur='$tanggal_retur' 
              WHERE id_retur_pembelian='$id_lama'";
    
    if (mysqli_query($conn, $query)) {
        $success = "Retur pembelian berhasil diupdate!";
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}

// Proses HAPUS
if (isset($_GET['hapus'])) {
    $id = clean_input($_GET['hapus']);
    
    // Ambil qty untuk kembalikan stok
    $query_get = "SELECT id_produk, qty_retur FROM transaksi_retur_pembelian WHERE id_retur_pembelian='$id'";
    $result_get = mysqli_query($conn, $query_get);
    $row_get = mysqli_fetch_assoc($result_get);
    
    $query = "DELETE FROM transaksi_retur_pembelian WHERE id_retur_pembelian='$id'";
    
    if (mysqli_query($conn, $query)) {
        // Kembalikan stok
        $update = "UPDATE produk SET stok = stok + {$row_get['qty_retur']} WHERE id_produk = '{$row_get['id_produk']}'";
        mysqli_query($conn, $update);
        
        $success = "Retur pembelian berhasil dihapus!";
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}

// Ambil data untuk edit
$edit_data = null;
if (isset($_GET['edit'])) {
    $id = clean_input($_GET['edit']);
    $query = "SELECT * FROM transaksi_retur_pembelian WHERE id_retur_pembelian='$id'";
    $result = mysqli_query($conn, $query);
    $edit_data = mysqli_fetch_assoc($result);
}

// Ambil data untuk dropdown
$query_supplier = "SELECT * FROM supplier ORDER BY nama_supplier";
$result_supplier = mysqli_query($conn, $query_supplier);

$query_produk = "SELECT * FROM produk ORDER BY nama_produk";
$result_produk = mysqli_query($conn, $query_produk);

// Ambil semua data retur pembelian dengan JOIN
$query = "SELECT r.*, s.nama_supplier, p.nama_produk 
          FROM transaksi_retur_pembelian r
          LEFT JOIN supplier s ON r.id_supplier = s.id_supplier
          LEFT JOIN produk p ON r.id_produk = p.id_produk
          ORDER BY r.tanggal_retur DESC";
$result = mysqli_query($conn, $query);

// Generate ID untuk form
$new_id = generate_id_retur();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Retur Pembelian - Toko Elektronik</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <!-- SIDEBAR -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>💗 Toko Elektronik</h2>
            </div>

            <div class="nav-section">
                <p class="nav-title">Master Data</p>
                <a class="nav-item" href="../masterdata/pelanggan.php">Pelanggan</a>
                <a class="nav-item" href="../masterdata/produk.php">Produk</a>
                <a class="nav-item" href="../masterdata/kategori.php">Kategori</a>
                <a class="nav-item" href="../masterdata/supplier.php">Supplier</a>
                <a class="nav-item" href="../masterdata/karyawan.php">Karyawan</a>
                <a class="nav-item" href="../masterdata/metode_pembayaran.php">Metode Pembayaran</a>
                <a class="nav-item" href="../masterdata/ekspedisi.php">Ekspedisi</a>
                <a class="nav-item" href="../masterdata/gudang.php">Gudang</a>
            </div>

            <div class="nav-section">
                <p class="nav-title">Transaksi</p>
                <a class="nav-item" href="transaksi_penjualan.php">Transaksi Penjualan</a>
                <a class="nav-item" href="transaksi_retur_penjualan.php">Retur Penjualan</a>
                <a class="nav-item active" href="transaksi_retur_pembelian.php">Retur Pembelian</a>
                <a class="nav-item" href="transaksi_pengiriman.php">Pengiriman</a>
                <a class="nav-item" href="transaksi_pembayaran.php">Pembayaran</a>
            </div>

            <div class="nav-section">
                <p class="nav-title">Laporan</p>
                <a class="nav-item" href="../laporan/laporan_penjualan.php">Laporan Penjualan</a>
                <a class="nav-item" href="../laporan/laporan_pengiriman.php">Laporan Pengiriman</a>
            </div>

            <div class="nav-section">
                <p class="nav-title">Dashboard</p>
                <a class="nav-item" href="../index.php">🏠 Dashboard</a>
            </div>
        </div>

        <!-- CONTENT -->
        <div class="content">
            <div class="header">
                <h1>Retur Pembelian ↩️</h1>
                <div class="user-avatar">A</div>
            </div>

            <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <button id="btnToggleForm" class="btn-primary mb-20">
                <?php echo $edit_data ? '✖ Batal Edit' : '+ Tambah Retur'; ?>
            </button>

            <!-- FORM -->
            <section class="form-container mb-20" id="formSection" style="<?php echo $edit_data ? '' : 'display: none;'; ?>">
                <h2 style="color: #d86aa3; margin-bottom: 20px;">
                    <?php echo $edit_data ? 'Edit Retur Pembelian' : 'Tambah Retur Pembelian'; ?>
                </h2>

                <form method="POST" action="">
                    <?php if ($edit_data): ?>
                    <input type="hidden" name="id_lama" value="<?php echo $edit_data['id_retur_pembelian']; ?>">
                    <?php endif; ?>
                    
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px;">
                        <div class="form-group">
                            <label>ID Retur</label>
                            <input type="text" name="id_retur_pembelian" class="form-control" 
                                   value="<?php echo $edit_data ? $edit_data['id_retur_pembelian'] : $new_id; ?>" 
                                   required>
                        </div>

                        <div class="form-group">
                            <label>Supplier</label>
                            <select name="id_supplier" class="form-control" required>
                                <option value="">Pilih Supplier</option>
                                <?php 
                                mysqli_data_seek($result_supplier, 0);
                                while($sup = mysqli_fetch_assoc($result_supplier)): 
                                ?>
                                    <option value="<?php echo $sup['id_supplier']; ?>"
                                        <?php echo ($edit_data && $edit_data['id_supplier'] == $sup['id_supplier']) ? 'selected' : ''; ?>>
                                        <?php echo $sup['nama_supplier']; ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Produk</label>
                            <select name="id_produk" class="form-control" required>
                                <option value="">Pilih Produk</option>
                                <?php 
                                mysqli_data_seek($result_produk, 0);
                                while($prod = mysqli_fetch_assoc($result_produk)): 
                                ?>
                                    <option value="<?php echo $prod['id_produk']; ?>"
                                        <?php echo ($edit_data && $edit_data['id_produk'] == $prod['id_produk']) ? 'selected' : ''; ?>>
                                        <?php echo $prod['nama_produk']; ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Qty Retur</label>
                            <input type="number" name="qty_retur" class="form-control" 
                                   value="<?php echo $edit_data ? $edit_data['qty_retur'] : '0'; ?>" 
                                   required>
                        </div>

                        <div class="form-group">
                            <label>Tanggal Retur</label>
                            <input type="date" name="tanggal_retur" class="form-control" 
                                   value="<?php echo $edit_data ? $edit_data['tanggal_retur'] : date('Y-m-d'); ?>" 
                                   required>
                        </div>

                        <div class="form-group" style="grid-column: span 3;">
                            <label>Alasan</label>
                            <textarea name="alasan" class="form-control" rows="3" required><?php echo $edit_data ? $edit_data['alasan'] : ''; ?></textarea>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" name="<?php echo $edit_data ? 'edit' : 'tambah'; ?>" class="btn-primary">
                            <?php echo $edit_data ? 'Update' : 'Simpan'; ?>
                        </button>
                        <?php if ($edit_data): ?>
                        <a href="transaksi_retur_pembelian.php" class="btn-cancel">Batal</a>
                        <?php endif; ?>
                    </div>
                </form>
            </section>

            <!-- TABLE -->
            <div class="table-container">
                <h3 style="color: #d86aa3; margin-bottom: 20px;">Daftar Retur Pembelian</h3>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID Retur</th>
                            <th>Tanggal</th>
                            <th>Supplier</th>
                            <th>Produk</th>
                            <th>Qty Retur</th>
                            <th>Alasan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if (mysqli_num_rows($result) > 0):
                            while ($row = mysqli_fetch_assoc($result)): 
                        ?>
                        <tr>
                            <td><?php echo $row['id_retur_pembelian']; ?></td>
                            <td><?php echo $row['tanggal_retur']; ?></td>
                            <td><?php echo $row['nama_supplier']; ?></td>
                            <td><?php echo $row['nama_produk']; ?></td>
                            <td><?php echo $row['qty_retur']; ?></td>
                            <td><?php echo $row['alasan']; ?></td>
                            <td>
                                <div class="action-buttons">
                                    <a href="?edit=<?php echo $row['id_retur_pembelian']; ?>" class="btn-edit">Edit</a>
                                    <a href="?hapus=<?php echo $row['id_retur_pembelian']; ?>" 
                                       class="btn-delete" 
                                       onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                                </div>
                            </td>
                        </tr>
                        <?php 
                            endwhile;
                        else:
                        ?>
                        <tr>
                            <td colspan="7" class="text-center">Belum ada data retur pembelian</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('btnToggleForm').addEventListener('click', function() {
            const form = document.getElementById('formSection');
            const btn = this;
            
            if (form.style.display === 'none') {
                form.style.display = 'block';
                btn.textContent = '✖ Tutup Form';
            } else {
                form.style.display = 'none';
                btn.textContent = '+ Tambah Retur';
            }
        });
    </script>
</body>
</html>