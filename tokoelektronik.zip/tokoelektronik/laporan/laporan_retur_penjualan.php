<?php
include '../config/database.php';

$query = "
SELECT 
    tr.id_retur_penjualan,
    tr.tanggal_retur,
    tr.qty_retur,
    tr.alasan,

    t.id_transaksi,
    p.nama AS nama_pelanggan,
    pr.nama_produk,
    k.nama AS nama_karyawan

FROM transaksi_retur_penjualan tr
JOIN transaksi_penjualan t 
    ON tr.id_transaksi = t.id_transaksi
JOIN pelanggan p 
    ON t.id_pelanggan = p.id_pelanggan
JOIN produk pr 
    ON tr.id_produk = pr.id_produk
JOIN karyawan k 
    ON tr.id_karyawan = k.id_karyawan

ORDER BY tr.tanggal_retur DESC
";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Retur Penjualan</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<div class="container">

    <!-- SIDEBAR -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h2>💗 Toko Elektronik</h2>
        </div>

        <div class="nav-section">
            <p class="nav-title">Laporan</p>
            <a class="nav-item" href="laporan_penjualan.php">Laporan Penjualan</a>
            <a class="nav-item active" href="laporan_retur_penjualan.php">Retur Penjualan</a>
        </div>

        <div class="nav-section">
            <a class="nav-item" href="../index.php">🏠 Dashboard</a>
        </div>
    </div>

    <!-- CONTENT -->
    <div class="content">
        <div class="header">
            <h1>Laporan Retur Penjualan</h1>
            <div class="user-avatar">A</div>
        </div>

        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID Retur</th>
                        <th>Tanggal</th>
                        <th>ID Transaksi</th>
                        <th>Pelanggan</th>
                        <th>Karyawan</th>
                        <th>Alasan</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?= $row['id_retur_penjualan']; ?></td>
<td><?= $row['tanggal_retur']; ?></td>
<td><?= $row['id_transaksi']; ?></td>
<td><?= $row['nama_pelanggan']; ?></td>
<td><?= $row['nama_produk']; ?></td>
<td><?= $row['qty_retur']; ?></td>
<td><?= $row['alasan']; ?></td>
<td><?= $row['nama_karyawan']; ?></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center">Belum ada data</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>
</div>

</body>
</html>
