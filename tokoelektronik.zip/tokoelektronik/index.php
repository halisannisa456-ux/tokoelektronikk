<?php
include 'config/database.php';

// Hitung statistik untuk dashboard
$query_produk = "SELECT COUNT(*) as total FROM produk";
$result_produk = mysqli_query($conn, $query_produk);
$total_produk = mysqli_fetch_assoc($result_produk)['total'];

$query_pelanggan = "SELECT COUNT(*) as total FROM pelanggan";
$result_pelanggan = mysqli_query($conn, $query_pelanggan);
$total_pelanggan = mysqli_fetch_assoc($result_pelanggan)['total'];

$query_penjualan = "SELECT COUNT(*) as total FROM transaksi_penjualan";
$result_penjualan = mysqli_query($conn, $query_penjualan);
$total_penjualan = mysqli_fetch_assoc($result_penjualan)['total'];

$query_pendapatan = "SELECT SUM(total_harga) as total FROM transaksi_penjualan WHERE status='Selesai'";
$result_pendapatan = mysqli_query($conn, $query_pendapatan);
$total_pendapatan = mysqli_fetch_assoc($result_pendapatan)['total'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Toko Elektronik</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
            background-color: #ffe7f3;
            color: #40243c;
            line-height: 1.6;
        }

        .container {
            display: flex;
            height: 100vh;
            overflow: hidden;
        }

        /* SIDEBAR */
        .sidebar {
            width: 260px;
            background: linear-gradient(180deg, #ec90bd 0%, #d86aa3 100%);
            color: white;
            overflow-y: auto;
            transition: all 0.3s ease;
            padding: 20px 0;
        }

        .sidebar-header {
            padding: 0 20px 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 20px;
        }

        .sidebar-header h2 {
            font-size: 1.5rem;
            font-weight: bold;
        }

        .nav-section {
            margin-bottom: 25px;
        }

        .nav-title {
            padding: 10px 20px;
            font-size: 0.75rem;
            text-transform: uppercase;
            color: #ffe3f1;
            margin-bottom: 0.5rem;
            font-weight: 600;
            letter-spacing: 1px;
        }

        .nav-item {
            display: block;
            padding: 12px 20px;
            color: #fff;
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }

        .nav-item:hover {
            background-color: rgba(255,255,255,0.15);
            border-left-color: #ffffff;
            padding-left: 25px;
        }

        .nav-item.active {
            background-color: #b85289;
            border-left-color: #ffffff;
        }

        /* CONTENT */
        .content {
            flex: 1;
            padding: 30px;
            overflow-y: auto;
            background-color: #ffe7f3;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding: 20px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(236, 144, 189, 0.2);
        }

        .header h1 {
            font-size: 32px;
            color: #d86aa3;
            font-weight: 600;
        }

        .user-avatar {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, #ec90bd 0%, #d86aa3 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 18px;
            cursor: pointer;
            box-shadow: 0 4px 8px rgba(236, 144, 189, 0.3);
            transition: transform 0.3s ease;
        }

        .user-avatar:hover {
            transform: scale(1.1);
        }

        /* CARDS */
        .card-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            padding: 25px;
            border-radius: 12px;
            color: white;
            box-shadow: 0 4px 15px rgba(236, 144, 189, 0.3);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(236, 144, 189, 0.4);
        }

        .stat-card h3 {
            font-size: 16px;
            font-weight: 500;
            margin-bottom: 10px;
            opacity: 0.9;
        }

        .stat-card p {
            font-size: 36px;
            font-weight: bold;
        }

        .stat-card.blue {
            background: linear-gradient(135deg, #ec90bd 0%, #d86aa3 100%);
        }

        .stat-card.green {
            background: linear-gradient(135deg, #ffaad7 0%, #e27ab0 100%);
        }

        .stat-card.purple {
            background: linear-gradient(135deg, #f598c9 0%, #d86aa3 100%);
        }

        .stat-card.orange {
            background: linear-gradient(135deg, #ffb6d8 0%, #e988b7 100%);
        }

        .welcome-card {
            background: linear-gradient(135deg, #ec90bd 0%, #d86aa3 100%);
            padding: 30px;
            border-radius: 12px;
            color: white;
            box-shadow: 0 4px 15px rgba(236, 144, 189, 0.3);
            margin-bottom: 30px;
        }

        .welcome-card p {
            font-size: 20px;
            font-weight: 500;
            margin: 0;
        }

        /* SCROLLBAR */
        .sidebar::-webkit-scrollbar,
        .content::-webkit-scrollbar {
            width: 8px;
        }

        .sidebar::-webkit-scrollbar-track {
            background: rgba(255,255,255,0.05);
        }

        .sidebar::-webkit-scrollbar-thumb {
            background: rgba(255,255,255,0.2);
            border-radius: 4px;
        }

        .content::-webkit-scrollbar-track {
            background: #ffe7f3;
        }

        .content::-webkit-scrollbar-thumb {
            background: #ec90bd;
            border-radius: 4px;
        }

        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
            }
            
            .card-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- SIDEBAR -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>Toko Elektronik</h2>
            </div>

            <div class="nav-section">
                <p class="nav-title">Master Data</p>
                <a class="nav-item" href="masterdata/pelanggan.php">Pelanggan</a>
                <a class="nav-item" href="masterdata/produk.php">Produk</a>
                <a class="nav-item" href="masterdata/kategori.php">Kategori</a>
                <a class="nav-item" href="masterdata/supplier.php">Supplier</a>
                <a class="nav-item" href="masterdata/karyawan.php">Karyawan</a>
                <a class="nav-item" href="masterdata/metode_pembayaran.php">Metode Pembayaran</a>
                <a class="nav-item" href="masterdata/ekspedisi.php">Ekspedisi</a>
                <a class="nav-item" href="masterdata/gudang.php">Gudang</a>
            </div>

            <div class="nav-section">
                <p class="nav-title">Transaksi</p>
                <a class="nav-item" href="transaksi/transaksi_penjualan.php">Transaksi Penjualan</a>
                <a class="nav-item" href="transaksi/transaksi_retur_penjualan.php">Retur Penjualan</a>
                <a class="nav-item" href="transaksi/transaksi_retur_pembelian.php">Retur Pembelian</a>
                <a class="nav-item" href="transaksi/transaksi_pengiriman.php">Pengiriman</a>
                <a class="nav-item" href="transaksi/transaksi_pembayaran.php">Pembayaran</a>
            </div>

            <div class="nav-section">
                <p class="nav-title">Laporan</p>
                <a class="nav-item" href="laporan/laporan_penjualan.php">Laporan Penjualan</a>
                <a class="nav-item" href="laporan/laporan_pengiriman.php">Laporan Pengiriman</a>
            </div>

            <div class="nav-section">
                <p class="nav-title">Dashboard</p>
                <a class="nav-item active" href="index.php">🏠 Dashboard</a>
            </div>
        </div>

        <!-- CONTENT -->
        <div class="content">
            <div class="header">
                <h1>Dashboard 💗</h1>
                <div class="user-avatar">A</div>
            </div>

            <div class="welcome-card">
                <p>Selamat datang di Sistem Informasi Toko Elektronik</p>
            </div>

    </div>
</body>
</html>