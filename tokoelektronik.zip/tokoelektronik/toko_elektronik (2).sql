-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 31, 2026 at 07:33 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `toko_elektronik`
--

-- --------------------------------------------------------

--
-- Table structure for table `detail_transaksi`
--

CREATE TABLE `detail_transaksi` (
  `id_detail` int(11) NOT NULL,
  `id_transaksi` varchar(5) NOT NULL,
  `id_produk` varchar(5) NOT NULL,
  `qty` int(11) NOT NULL CHECK (`qty` > 0),
  `harga_satuan` int(11) NOT NULL CHECK (`harga_satuan` >= 0),
  `subtotal` int(11) GENERATED ALWAYS AS (`qty` * `harga_satuan`) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `detail_transaksi`
--

INSERT INTO `detail_transaksi` (`id_detail`, `id_transaksi`, `id_produk`, `qty`, `harga_satuan`) VALUES
(1, 'T001', 'PR001', 1, 3500000);

-- --------------------------------------------------------

--
-- Table structure for table `ekspedisi`
--

CREATE TABLE `ekspedisi` (
  `id_ekspedisi` varchar(5) NOT NULL,
  `nama_ekspedisi` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ekspedisi`
--

INSERT INTO `ekspedisi` (`id_ekspedisi`, `nama_ekspedisi`) VALUES
('EX001', 'JNE');

-- --------------------------------------------------------

--
-- Table structure for table `gudang`
--

CREATE TABLE `gudang` (
  `id_gudang` varchar(5) NOT NULL,
  `nama_gudang` varchar(100) NOT NULL,
  `lokasi` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gudang`
--

INSERT INTO `gudang` (`id_gudang`, `nama_gudang`, `lokasi`) VALUES
('GD002', 'Gudang Utama', 'Banjarmasin');

-- --------------------------------------------------------

--
-- Table structure for table `karyawan`
--

CREATE TABLE `karyawan` (
  `id_karyawan` varchar(5) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `posisi` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `karyawan`
--

INSERT INTO `karyawan` (`id_karyawan`, `nama`, `posisi`) VALUES
('K001', 'Andi', 'Admin'),
('K002', 'Budi', 'Kasir'),
('KR001', 'Rina', 'Kasir');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` varchar(5) NOT NULL,
  `nama_kategori` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
('KT001', 'Smartphone');

-- --------------------------------------------------------

--
-- Table structure for table `metode_pembayaran`
--

CREATE TABLE `metode_pembayaran` (
  `id_payment` varchar(5) NOT NULL,
  `metode` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `metode_pembayaran`
--

INSERT INTO `metode_pembayaran` (`id_payment`, `metode`) VALUES
('MP001', 'Transfer Bank'),
('MP002', 'Cash On Delivery (COD)'),
('MP003', 'Gopay'),
('MP004', 'OVO'),
('MP006', 'Shoppepay'),
('PM001', 'Transfer');

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` varchar(5) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `kota` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nama`, `kota`) VALUES
('PL001', 'Andi Saputra', 'Jakarta');

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id_produk` varchar(5) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `id_kategori` varchar(5) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id_produk`, `nama_produk`, `id_kategori`, `harga`) VALUES
('PR001', 'Samsung A34', 'KT001', 3500000),
('PR002', 'Charger Samsung', 'KT001', 150000);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `id_supplier` varchar(5) NOT NULL,
  `nama_supplier` varchar(100) NOT NULL,
  `kota` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`id_supplier`, `nama_supplier`, `kota`) VALUES
('SP001', 'PT. Sumber Elektronik', 'Jakarta'),
('SP002', 'CV. Listrik Jaya', 'Bandung'),
('SP003', 'UD. Tekno Mandiri', 'Surabaya'),
('SP004', 'UD. Jamur Borneo', 'banjarbaru');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_pembayaran`
--

CREATE TABLE `transaksi_pembayaran` (
  `id_pembayaran` varchar(7) NOT NULL,
  `id_transaksi` varchar(5) NOT NULL,
  `id_payment` varchar(5) NOT NULL,
  `jumlah` int(11) NOT NULL CHECK (`jumlah` > 0),
  `tanggal_bayar` date NOT NULL,
  `status` varchar(50) DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi_pembayaran`
--

INSERT INTO `transaksi_pembayaran` (`id_pembayaran`, `id_transaksi`, `id_payment`, `jumlah`, `tanggal_bayar`, `status`) VALUES
('BYR002', 'TR002', 'MP004', 23, '2026-01-31', 'Berhasil');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_pengiriman`
--

CREATE TABLE `transaksi_pengiriman` (
  `id_pengiriman` varchar(7) NOT NULL,
  `id_transaksi` varchar(5) NOT NULL,
  `id_ekspedisi` varchar(5) NOT NULL,
  `status` varchar(50) DEFAULT 'Pending',
  `tanggal_kirim` date DEFAULT NULL,
  `tanggal_terima` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi_pengiriman`
--

INSERT INTO `transaksi_pengiriman` (`id_pengiriman`, `id_transaksi`, `id_ekspedisi`, `status`, `tanggal_kirim`, `tanggal_terima`) VALUES
('KRM003', 'TR003', 'EX001', 'Dikirim', '2026-02-28', '2026-03-10'),
('PG001', 'T001', 'EX001', 'Dikirim', '2026-01-16', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_penjualan`
--

CREATE TABLE `transaksi_penjualan` (
  `id_transaksi` varchar(5) NOT NULL,
  `id_pelanggan` varchar(5) NOT NULL,
  `id_karyawan` varchar(5) NOT NULL,
  `tanggal_transaksi` date NOT NULL DEFAULT curdate(),
  `status` varchar(20) DEFAULT 'Pending',
  `total_harga` decimal(15,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi_penjualan`
--

INSERT INTO `transaksi_penjualan` (`id_transaksi`, `id_pelanggan`, `id_karyawan`, `tanggal_transaksi`, `status`, `total_harga`) VALUES
('T001', 'PL001', 'KR001', '2026-01-15', 'Selesai', 3500000.00),
('TR002', 'PL001', 'K002', '2026-01-22', 'Pending', 100000.00),
('TR003', 'PL001', 'K002', '2026-01-26', 'Diproses', 0.34);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_retur_pembelian`
--

CREATE TABLE `transaksi_retur_pembelian` (
  `id_retur_pembelian` varchar(7) NOT NULL,
  `id_supplier` varchar(5) NOT NULL,
  `id_produk` varchar(5) NOT NULL,
  `qty_retur` int(11) NOT NULL CHECK (`qty_retur` > 0),
  `alasan` varchar(100) DEFAULT NULL,
  `tanggal_retur` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi_retur_pembelian`
--

INSERT INTO `transaksi_retur_pembelian` (`id_retur_pembelian`, `id_supplier`, `id_produk`, `qty_retur`, `alasan`, `tanggal_retur`) VALUES
('RB001', 'SP001', 'PR001', 1, 'Barang rusak', '2025-01-10'),
('RB002', 'SP002', 'PR001', 2, 'Salah kirim barang', '2025-01-12'),
('RB003', 'SP001', 'PR001', 1, 'Kualitas aman', '2025-01-15');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_retur_penjualan`
--

CREATE TABLE `transaksi_retur_penjualan` (
  `id_retur_penjualan` varchar(7) NOT NULL,
  `id_transaksi` varchar(5) NOT NULL,
  `id_produk` varchar(5) NOT NULL,
  `qty_retur` int(11) NOT NULL CHECK (`qty_retur` > 0),
  `alasan` varchar(100) DEFAULT NULL,
  `id_karyawan` varchar(5) NOT NULL,
  `tanggal_retur` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi_retur_penjualan`
--

INSERT INTO `transaksi_retur_penjualan` (`id_retur_penjualan`, `id_transaksi`, `id_produk`, `qty_retur`, `alasan`, `id_karyawan`, `tanggal_retur`) VALUES
('RJ001', 'T001', 'PR001', 1, 'Barang PECAH', 'K001', '2026-01-20'),
('RJ002', 'T001', 'PR002', 2, 'Tidak sesuai pesanan', 'K002', '2026-01-22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `detail_transaksi`
--
ALTER TABLE `detail_transaksi`
  ADD PRIMARY KEY (`id_detail`),
  ADD KEY `idx_transaksi` (`id_transaksi`),
  ADD KEY `idx_produk` (`id_produk`);

--
-- Indexes for table `ekspedisi`
--
ALTER TABLE `ekspedisi`
  ADD PRIMARY KEY (`id_ekspedisi`);

--
-- Indexes for table `gudang`
--
ALTER TABLE `gudang`
  ADD PRIMARY KEY (`id_gudang`);

--
-- Indexes for table `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`id_karyawan`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `metode_pembayaran`
--
ALTER TABLE `metode_pembayaran`
  ADD PRIMARY KEY (`id_payment`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`),
  ADD KEY `id_kategori` (`id_kategori`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`id_supplier`);

--
-- Indexes for table `transaksi_pembayaran`
--
ALTER TABLE `transaksi_pembayaran`
  ADD PRIMARY KEY (`id_pembayaran`),
  ADD UNIQUE KEY `id_transaksi` (`id_transaksi`),
  ADD KEY `id_payment` (`id_payment`),
  ADD KEY `idx_transaksi` (`id_transaksi`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `transaksi_pengiriman`
--
ALTER TABLE `transaksi_pengiriman`
  ADD PRIMARY KEY (`id_pengiriman`),
  ADD UNIQUE KEY `id_transaksi` (`id_transaksi`),
  ADD KEY `id_ekspedisi` (`id_ekspedisi`),
  ADD KEY `idx_transaksi` (`id_transaksi`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `transaksi_penjualan`
--
ALTER TABLE `transaksi_penjualan`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `id_pelanggan` (`id_pelanggan`),
  ADD KEY `id_karyawan` (`id_karyawan`),
  ADD KEY `idx_tanggal` (`tanggal_transaksi`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `transaksi_retur_pembelian`
--
ALTER TABLE `transaksi_retur_pembelian`
  ADD PRIMARY KEY (`id_retur_pembelian`),
  ADD KEY `idx_supplier` (`id_supplier`),
  ADD KEY `idx_produk` (`id_produk`);

--
-- Indexes for table `transaksi_retur_penjualan`
--
ALTER TABLE `transaksi_retur_penjualan`
  ADD PRIMARY KEY (`id_retur_penjualan`),
  ADD KEY `id_karyawan` (`id_karyawan`),
  ADD KEY `idx_transaksi` (`id_transaksi`),
  ADD KEY `idx_produk` (`id_produk`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `detail_transaksi`
--
ALTER TABLE `detail_transaksi`
  MODIFY `id_detail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `detail_transaksi`
--
ALTER TABLE `detail_transaksi`
  ADD CONSTRAINT `detail_transaksi_ibfk_1` FOREIGN KEY (`id_transaksi`) REFERENCES `transaksi_penjualan` (`id_transaksi`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `detail_transaksi_ibfk_2` FOREIGN KEY (`id_produk`) REFERENCES `produk` (`id_produk`) ON UPDATE CASCADE;

--
-- Constraints for table `produk`
--
ALTER TABLE `produk`
  ADD CONSTRAINT `produk_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id_kategori`) ON UPDATE CASCADE;

--
-- Constraints for table `transaksi_pembayaran`
--
ALTER TABLE `transaksi_pembayaran`
  ADD CONSTRAINT `transaksi_pembayaran_ibfk_1` FOREIGN KEY (`id_transaksi`) REFERENCES `transaksi_penjualan` (`id_transaksi`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `transaksi_pembayaran_ibfk_2` FOREIGN KEY (`id_payment`) REFERENCES `metode_pembayaran` (`id_payment`) ON UPDATE CASCADE;

--
-- Constraints for table `transaksi_pengiriman`
--
ALTER TABLE `transaksi_pengiriman`
  ADD CONSTRAINT `transaksi_pengiriman_ibfk_1` FOREIGN KEY (`id_transaksi`) REFERENCES `transaksi_penjualan` (`id_transaksi`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `transaksi_pengiriman_ibfk_2` FOREIGN KEY (`id_ekspedisi`) REFERENCES `ekspedisi` (`id_ekspedisi`) ON UPDATE CASCADE;

--
-- Constraints for table `transaksi_penjualan`
--
ALTER TABLE `transaksi_penjualan`
  ADD CONSTRAINT `transaksi_penjualan_ibfk_1` FOREIGN KEY (`id_pelanggan`) REFERENCES `pelanggan` (`id_pelanggan`) ON UPDATE CASCADE,
  ADD CONSTRAINT `transaksi_penjualan_ibfk_2` FOREIGN KEY (`id_karyawan`) REFERENCES `karyawan` (`id_karyawan`) ON UPDATE CASCADE;

--
-- Constraints for table `transaksi_retur_pembelian`
--
ALTER TABLE `transaksi_retur_pembelian`
  ADD CONSTRAINT `transaksi_retur_pembelian_ibfk_1` FOREIGN KEY (`id_supplier`) REFERENCES `supplier` (`id_supplier`) ON UPDATE CASCADE,
  ADD CONSTRAINT `transaksi_retur_pembelian_ibfk_2` FOREIGN KEY (`id_produk`) REFERENCES `produk` (`id_produk`) ON UPDATE CASCADE;

--
-- Constraints for table `transaksi_retur_penjualan`
--
ALTER TABLE `transaksi_retur_penjualan`
  ADD CONSTRAINT `transaksi_retur_penjualan_ibfk_1` FOREIGN KEY (`id_transaksi`) REFERENCES `transaksi_penjualan` (`id_transaksi`) ON UPDATE CASCADE,
  ADD CONSTRAINT `transaksi_retur_penjualan_ibfk_2` FOREIGN KEY (`id_produk`) REFERENCES `produk` (`id_produk`) ON UPDATE CASCADE,
  ADD CONSTRAINT `transaksi_retur_penjualan_ibfk_3` FOREIGN KEY (`id_karyawan`) REFERENCES `karyawan` (`id_karyawan`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
